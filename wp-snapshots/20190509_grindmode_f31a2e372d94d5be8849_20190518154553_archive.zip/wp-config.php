<?php
define('DB_NAME', '');
define('DB_USER', '');
define('DB_PASSWORD', '');

define('DB_HOST', '');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

define('AUTH_KEY',         'S8mt9Vhd8Eca30belsXowRaIhQgFEf2u2AB3jYrg');
define('SECURE_AUTH_KEY',  '2IxhBR0Uiv6UHNULsbQdrYn2vD51AQ0cJcuesnfC');
define('LOGGED_IN_KEY',    'Vmh6gE8iDkXJWBa4Ec7yWc02Qtvs4VWXEqMV4lbU');
define('NONCE_KEY',        'jHbcrmiwaHb2Ic5MEfrOMYQGDc1j2VL10gHLW91T');
define('AUTH_SALT',        'ntQVgLVu9O5PJRG9v19rolFdt2JTMkogEQ8MGLLX');
define('SECURE_AUTH_SALT', 'M5LNUfk7PUcSDEhVysemNiNMXi9QcFvNKSlsk6yV');
define('LOGGED_IN_SALT',   'MLhAnbUFEOn0EUs3JhpOOD7cGSCczZ1g6phnFsPs');
define('NONCE_SALT',       '0I5gSAJ4lsW84jrKGc9fcLoNGAEXq3fImjDr6F9h');

$table_prefix  = 'wp_1d9364265e_';

define('SP_REQUEST_URL', ($_SERVER['HTTPS'] ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']);

define('WP_SITEURL', SP_REQUEST_URL);
define('WP_HOME', SP_REQUEST_URL);

/* Change WP_MEMORY_LIMIT to increase the memory limit for public pages. */
define('WP_MEMORY_LIMIT', '256M');

/* Uncomment and change WP_MAX_MEMORY_LIMIT to increase the memory limit for admin pages. */
//define('WP_MAX_MEMORY_LIMIT', '256M');

/* That's all, stop editing! Happy blogging. */

if ( !defined('ABSPATH') )
        define('ABSPATH', dirname(__FILE__) . '/');

require_once(ABSPATH . 'wp-settings.php');
